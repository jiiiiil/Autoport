import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export default function HomePage() {
  return (
    <>
      <Navbar />

      <main className="min-h-screen flex items-center justify-center">

        <h1 className="text-6xl font-bold">
          Landing Page Coming Next →
        </h1>

      </main>

      <Footer />
    </>
  );
}